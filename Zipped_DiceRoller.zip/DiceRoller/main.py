from rich import *
import random


def play():
    dice = []
    total = 0
    print('[bold yellow]How many dice would you like to roll?')
    try:
        num_of_dice = int(input('\n'))
        for die in range(0, num_of_dice):
            dice.append([die + 1, random.randint(1, 6)])
        for die in dice:
            print('[bold green]Dice Number: ' + str(die[0]) + '\nValue: ' + str(die[1]) + '\n')
            total += die[1]
        print('[bold green]Total Value: ' + str(total) + '\n')
        run()
    except ValueError:
        print('[bold red][italic]\nThat is not a number, try again\n')
        play()


def stop():
    print('[bold green]\nProgram Terminated Successfully')

def run():
    print('[bold yellow]What would you like to do? (play, stop)\n')
    choice_1 = input('\n')
    if choice_1 == 'play':
        play()
    elif choice_1 == 'stop':
        stop()
    else:
        print('[bold red][italic]\nThat command doesn\'t exist, please try again\n')
        run()
if __name__ == '__main__':
    run()